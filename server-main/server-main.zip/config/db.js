import mongoose from "mongoose";

const connectDB = () => {
  mongoose
    .connect(
      "mongodb+srv://zainwaseem9371:fUYHbAFlPTbkKz6i@cluster0.xo8i9an.mongodb.net/"
    )
    .then(() => console.log(`Datebase Connected`))
    .catch((error) => console.log(error.message));
};
export default connectDB;
// zainwaseem9371;
// fUYHbAFlPTbkKz6i;
